const express = require('express');
const router = express.Router();
const blogPostController = require('../controller/blogpostController');
const authMiddleware = require('../middleware/authMiddleware');

// Create a new blog post
router.post('/', authMiddleware, blogPostController.createPost);

// Read a single blog post by id
router.get('/:id', blogPostController.readPost);

// Update a blog post by id
router.put('/:id', authMiddleware, blogPostController.updatePost);

// Delete a blog post by id
router.delete('/:id', authMiddleware, blogPostController.deletePost);

// List all blog posts with pagination
router.get('/', blogPostController.listPosts);

// Route for rating a post
router.post('/:id/rate', authMiddleware, blogPostController.ratePost);

// Route for commenting on a post
router.post('/:id/comment', authMiddleware, blogPostController.commentOnPost);

// Route for deleting comment on a post
router.delete('/:postId/comments/:commentId', authMiddleware, blogPostController.deleteComment);


module.exports = router;

