const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/authMiddleware');
const interactionController = require('../controller/interactioncontroller');

//to follow a user
router.post('/follow/:userId', authMiddleware, interactionController.followUser);

//to unfollow a user
router.post('/unfollow/:userId', authMiddleware, interactionController.unfollowUser);

//to view feed
router.get('/feed', authMiddleware, interactionController.getUserFeed);

//to see notifications
router.get('/notifications', authMiddleware, interactionController.getNotifications);

module.exports = router;

