const express = require('express');
const router = express.Router(); 
const User = require('../models/user'); 
const jwt = require('jsonwebtoken');
const userController = require('../controller/userController');
const authMiddleware = require('../middleware/authMiddleware');

// Secret code for admin registration
const ADMIN_SECRET_CODE = process.env.ADMIN_SECRET_CODE;

router.post('/register', async (req, res) => {
  try {
    let { username, email, password, adminCode } = req.body;
    let role = 'regular'; // Default role

    // Check if user already exists
    let user = await User.findOne({ email });
    if (user) {
      return res.status(400).json({ message: 'User already exists' });
    }

    // If the adminCode is provided and matches the secret admin code, set the role to admin
    if (adminCode && adminCode === ADMIN_SECRET_CODE) {
      role = 'admin';
    }

    // Create a new user with the role
    user = new User({ username, email, password, role });
    await user.save();

    //send a success message
    res.status(201).json({ message: 'User registered successfully' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});


// Login endpoint
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Check if user exists
    const user = await User.findOne({ email });
    if (!user ) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Check if password matches
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }
    
    // Create token
    const token = jwt.sign({ userId: user._id }, process.env.SECRET_KEY, { expiresIn: '1h' });
    try {
      const decoded = jwt.verify(token, process.env.SECRET_KEY);
      console.log('Verification successful', decoded);
    } catch (error) {
      console.error('Verification failed', error);
    }
    
    res.json({ token });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

//endpoint for getting user profile
router.get('/:userId', authMiddleware, userController.getUserProfile);

//endpoint for updating profile
router.put('/:userId', authMiddleware, userController.updateUserProfile);

module.exports = router;
