const express = require('express');
const router = express.Router();
const adminController = require('../controller/adminController');
const { adminMiddleware } = require('../middleware/adminMiddleware'); // You will need to create this middleware

//to view users
router.get('/users', adminMiddleware, adminController.viewAllUsers);

//to block user
router.post('/user/block/:userId', adminMiddleware, adminController.blockUser);

//to unblock user
router.post('/user/unblock/:userId', adminMiddleware, adminController.unblockUser);

//list all blogs
router.get('/blogposts', adminMiddleware, adminController.listAllBlogPosts);

//view a specific post
router.get('/blogpost/:postId', adminMiddleware, adminController.viewParticularPost);

//disable post
router.post('/blogpost/disable/:postId', adminMiddleware, adminController.disableBlogPost);

//enable post
router.post('/blogpost/enable/:postId', adminMiddleware, adminController.enableBlogPost);

module.exports = router;
