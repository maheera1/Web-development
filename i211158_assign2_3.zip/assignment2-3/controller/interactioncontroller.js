const User = require('../models/user');
const Notification= require('../models/interactionschema');
const BlogPost = require('../models/blogpostschema'); 


exports.followUser = async (req, res) => {
    const userId = req.user.id; // ID of current user
    const targetUserId = req.params.userId; // ID of the user to follow
  
    try {
      // Add the targetUserId to the current user's follows array
      await User.findByIdAndUpdate(userId, {
        $addToSet: { follows: targetUserId } //prevent duplicates
      });
      const notification = new Notification({
        user: targetUserId,
        type: 'newFollower',
        createdBy: userId,
      });
      await notification.save();
  
      res.status(200).json({ message: `You are now following user ${targetUserId}` });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  };
  
  exports.unfollowUser = async (req, res) => {
    const userId = req.user.id;
    const targetUserId = req.params.userId;
  
    try {
      // Remove the targetUserId from the current user's follows array
      await User.findByIdAndUpdate(userId, {
        $pull: { follows: targetUserId } 
      });
     
      res.status(200).json({ message: `You have unfollowed user ${targetUserId}` });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  };

  exports.getUserFeed = async (req, res) => {
    const userId = req.user.id; // The ID of the logged-in user
  
    try {
      const user = await User.findById(userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
  
      const posts = await BlogPost.find({
        author: { $in: user.follows }
      }).sort({ createdAt: -1 }); // Fetch posts from followed users, sorted by creation date
  
      res.status(200).json(posts);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  };
  
  

  exports.getNotifications = async (req, res) => {
    const userId = req.user.id;
  
    try {
      const notifications = await Notification.find({
        user: userId
      }).sort({ createdAt: -1 }); // Sorting by most recent first
  
      res.status(200).json(notifications);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  };
  
  