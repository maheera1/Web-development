const User = require('../models/user');
const BlogPost = require('../models/blogpostschema');

exports.viewAllUsers = async (req, res) => {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skipIndex = (page - 1) * limit;
  
    try {
      const count = await User.countDocuments();
      const users = await User.find()
        .sort({ _id: 1 }) // Sort by user ID or another parameter
        .limit(limit)
        .skip(skipIndex)
        .select('-password') // Exclude the password field
        .exec();
  
      res.status(200).json({
        count,
        currentPage: page,
        totalPages: Math.ceil(count / limit),
        users
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  };
  

  exports.blockUser = async (req, res) => {
    const userId = req.params.userId; // The ID of the user to block
  
    try {
      // Find the user by ID and update their 'blocked' status to true
      const user = await User.findByIdAndUpdate(userId, { blocked: true }, { new: true });
  
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
  
      // Respond with a success message
      res.status(200).json({ message: `User ${userId} has been blocked` });
    } catch (error) {
      // If an error occurs, send a 500 status code and the error message
      res.status(500).json({ message: error.message });
    }
  };

  exports.unblockUser = async (req, res) => {
    const userId = req.params.userId; // The ID of the user to unblock
  
    try {
      // Find the user by ID and update their 'blocked' status to false
      const user = await User.findByIdAndUpdate(userId, { blocked: false }, { new: true });
  
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
  
      // Respond with a success message
      res.status(200).json({ message: `User ${userId} has been unblocked` });
    } catch (error) {
      // If an error occurs, send a 500 status code and the error message
      res.status(500).json({ message: error.message });
    }
  };

  exports.listAllBlogPosts = async (req, res) => {
    try {
      const posts = await BlogPost.aggregate([
        {
            $match: {
              disabled: { $ne: true } //exclude disabled posts from the results
            }
          },
        {
          $lookup: {
            from: User.collection.name,
            localField: 'author',
            foreignField: '_id',
            as: 'authorDetails'
          }
        },
        // Unwind the result to deconstruct the array
        {
          $unwind: '$authorDetails'
        },
        // Add a field for averageRating by calculating the average of ratings.rating
        {
          $addFields: {
            averageRating: { $avg: '$ratings.rating' }
          }
        },
        // Project the desired fields
        {
          $project: {
            title: 1,
            'authorDetails.username': 1, // Include the author's username
            createdAt: 1,
            averageRating: 1,
            disabled: 1 // Include disabled status to identify if the post is disabled
          }
        }
      ]);
  
      res.status(200).json(posts);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  };
  exports.viewParticularPost = async (req, res) => {
    const postId = req.params.postId; // The ID of the blog post to retrieve
  
    try {
      const post = await BlogPost.findById(postId)
        .populate('author', 'username') 
        .populate('comments.user', 'username');
  
      if (!post) {
        return res.status(404).json({ message: 'Blog post not found' });
      }
  
      res.status(200).json(post);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  };

// Disable a blog post
exports.disableBlogPost = async (req, res) => {
    const postId = req.params.postId; // The ID of the blog post to disable
  
    try {
      const post = await BlogPost.findByIdAndUpdate(postId, { disabled: true }, { new: true });
  
      if (!post) {
        return res.status(404).json({ message: 'Blog post not found' });
      }
  
      res.status(200).json({ message: `Blog post ${postId} has been disabled`, post });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  };
  
  // Enable a blog post
  exports.enableBlogPost = async (req, res) => {
    const postId = req.params.postId; // The ID of the blog post to enable
  
    try {
      const post = await BlogPost.findByIdAndUpdate(postId, { disabled: false }, { new: true });
  
      if (!post) {
        return res.status(404).json({ message: 'Blog post not found' });
      }
  
      res.status(200).json({ message: `Blog post ${postId} has been enabled`, post });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  };
  
