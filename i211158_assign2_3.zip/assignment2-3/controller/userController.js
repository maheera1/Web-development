const User = require('../models/user');

// Retrieve user profile
exports.getUserProfile = async (req, res) => {
    try {
        const user = await User.findById(req.params.userId);
        if (!user) {
            return res.status(404).send({ message: 'User not found' });
        }
        
        // Exclude sensitive information
        user.password = undefined;
        res.send(user);
    } catch (error) {
        res.status(500).send({ message: 'Error retrieving user profile' });
    }
};

// Update user profile
exports.updateUserProfile = async (req, res) => {
    try {
        const user = await User.findById(req.params.userId);
        if (!user) {
            return res.status(404).send({ message: 'User not found' });
        }
        if (user._id.toString() !== req.user.id && req.user.role !== 'admin') {
            return res.status(403).send({ message: 'Unauthorized to update this profile' });
        }
        // Update user profile
        const updatedUser = await User.findByIdAndUpdate(req.params.userId, req.body, { new: true });
        updatedUser.password = undefined;
        res.send(updatedUser);
    } catch (error) {
        res.status(500).send({ message: 'Error updating user profile' });
    }
};
