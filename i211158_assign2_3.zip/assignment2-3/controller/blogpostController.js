const BlogPost = require('../models/blogpostschema');

exports.createPost = async (req, res) => {
    const { title, content } = req.body;
    const author = req.user.id; 

    // Validation
    if (!title || !content) {
        return res.status(400).json({ message: 'Title and content are required.' });
    }

    try {
        const newPost = new BlogPost({ title, content, author });
        const post = await newPost.save();
        res.status(201).json(post);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.readPost = async (req, res) => {
    const { id } = req.params;

    try {
        const post = await BlogPost.findById(id);
        if (!post) {
            return res.status(404).json({ message: 'Post not found' });
        }
        res.status(200).json(post);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.updatePost = async (req, res) => {
    const { id } = req.params;
    const { title, content } = req.body;
    const userId = req.user.id;

    if (!title && !content) {
        return res.status(400).json({ message: 'There is nothing to update.' });
    }

    try {
        const post = await BlogPost.findById(id);
        if (!post) {
            return res.status(404).json({ message: 'Post not found' });
        }
        if (post.author.toString() !== userId) {
            return res.status(403).json({ message: 'User not authorized to update this post' });
        }

        post.title = title || post.title;
        post.content = content || post.content;
        post.updatedAt = Date.now();

        await post.save();
        res.status(200).json(post);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.deletePost = async (req, res) => {
    const { id } = req.params;
    const userId = req.user.id; 
  
    try {
      // Find the post to ensure it exists and to check the author
      const post = await BlogPost.findById(id);
  
      // Check if the post exists
      if (!post) {
        return res.status(404).json({ message: 'Post not found' });
      }
  
      // Check if the logged-in user is the author of the post
      if (post.author.toString() !== userId) {
        return res.status(403).json({ message: 'User not authorized to delete this post' });
      }
  
      // Use findByIdAndDelete to remove the post
      await BlogPost.findByIdAndDelete(id);
      res.status(200).json({ message: 'Post deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  };
  
  
  exports.listPosts = async (req, res) => {
    const { page = 1, limit = 10, title, sortBy, authorId, keyword } = req.query;

    try {
        let query = {};

        // Filter by title if it's provided
        if (title) {
            query.title = { $regex: title, $options: 'i' };
        }

        // Filter by authorId if it's provided
        if (authorId) {
            query.author = authorId;
        }

        // Filter by keyword present in title or content
        if (keyword) {
            query.$or = [
                { title: { $regex: keyword, $options: 'i' } },
                { content: { $regex: keyword, $options: 'i' } }
            ];
        }

        const postsQuery = BlogPost.find(query);

        // Sort the posts if sortBy is provided
        if (sortBy) {
            //allow specifying order direction (asc or desc)
            const sortOrder = req.query.order === 'desc' ? -1 : 1;
            postsQuery.sort({ [sortBy]: sortOrder });
        }

        const posts = await postsQuery
            .skip((page - 1) * limit)
            .limit(parseInt(limit))
            .exec();

        // Count the total number of posts 
        const count = await BlogPost.countDocuments(query);

        res.status(200).json({
            posts,
            count,
            totalPages: Math.ceil(count / limit),
            currentPage: parseInt(page) // Ensure this is a number
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


exports.ratePost = async (req, res) => {
    const { id } = req.params;
    const userId = req.user.id; 
    const { rating } = req.body;

    if (rating < 1 || rating > 5) {
        return res.status(400).json({ message: 'Rating must be between 1 and 5.' });
    }

    try {
        const post = await BlogPost.findById(id);

        if (!post) {
            return res.status(404).json({ message: 'Post not found' });
        }

        // Check if the post has already been rated by this user
        const existingRating = post.ratings.find(r => r.user.toString() === userId);
        if (existingRating) {
            existingRating.rating = rating;
        } else {
            post.ratings.push({ user: userId, rating });
        }

        await post.save();
        res.status(200).json(post.ratings);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.commentOnPost = async (req, res) => {
    const { id } = req.params;
    const userId = req.user.id; 
    const { comment } = req.body;
    // Validation for comment
    if (!comment.trim()) {
        return res.status(400).json({ message: 'Comment cannot be empty.' });
    }

    try {
        const post = await BlogPost.findById(id);

        if (!post) {
            return res.status(404).json({ message: 'Post not found' });
        }

        post.comments.push({
            user: userId,
            comment,
            createdAt: new Date()
        });

        await post.save();
        res.status(201).json(post.comments);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.deleteComment = async (req, res) => {
    const { postId, commentId } = req.params; 
    const userId = req.user.id;
  
    try {
      const post = await BlogPost.findById(postId);
      if (!post) {
        return res.status(404).json({ message: 'Post not found' });
      }
  
      // Find the index of the comment by its ID
      const commentIndex = post.comments.findIndex(c => c._id.toString() === commentId);
  
      // If comment not found or user is not the author of the comment
      if (commentIndex === -1 || post.comments[commentIndex].user.toString() !== userId) {
        return res.status(404).json({ message: 'Comment not found or user not authorized' });
      }
  
      // Remove the comment by its index
      post.comments.splice(commentIndex, 1);
  
      // Save the post without the comment
      await post.save();
      res.status(200).json({ message: 'Comment deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  };
  
  