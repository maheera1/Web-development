const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true
  },
  email: {
    type: String,
    required: true,
    unique: true
  },
  password: {
    type: String,
    required: true
  },
  role: {
    type: String,
    default: 'regular',
    enum: ['regular', 'admin']
}

});

// Pre-save hook to hash the password before saving it to the database
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();

  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (err) {
    next(err);
  }
});

// Method to compare entered password with hashed password in the database
userSchema.methods.comparePassword = async function (candidatePassword) {
    return await bcrypt.compare(candidatePassword, this.password);
  };
  
  userSchema.add({
    follows: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    }]
  });

  userSchema.add({
    blocked: { type: Boolean, default: false }
  });

const User = mongoose.model('User', userSchema);
module.exports = User;
