const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
require('dotenv').config();

const app = express();
app.use(cors({ origin: '*' }));
app.use(express.json());

//USER AUTHENTICATION
const authRoutes = require('./routes/auth');
app.use('/api/auth', authRoutes);

const userController = require('./controller/userController'); 
const authMiddleware = require('./middleware/authMiddleware');
app.get('/users/:userId', authMiddleware, userController.getUserProfile);
app.put('/users/:userId', authMiddleware, userController.updateUserProfile);

//BLOG POST (CONTAINS SEARCH TOO)
const blogPostRoutes = require('./routes/blogpostroutes');
app.use('/api/posts', blogPostRoutes);

//INTERACTION
const interactionRoutes = require('./routes/interactionroutes');
app.use('/api/interactions', interactionRoutes);

//ADMIN OPERATIONS
const adminRoutes = require('./routes/adminRoutes');
const { adminMiddleware } = require('./middleware/adminMiddleware');
app.use(authMiddleware);
app.use('/api/admin',adminMiddleware, adminRoutes);

// Basic route
app.get("/", (req, res) => {
    res.json({ "Message": "Hello" });
});

// MongoDB connection
mongoose.connect(process.env.MONGODB_STRING)
    .then(() => {
        console.log("Connected to MongoDB");
    })
    .catch(err => {
        console.log(err);
    });

const port = process.env.PORT || 3000;
app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
